<?php
/*
if (!defined('WC_BASE')) define('WC_BASE', dirname(__FILE__));
$ref=WC_BASE."/index.php";
if ($ref!=$_SERVER['SCRIPT_FILENAME']){
	header("Location: index.php");
	exit();
}
*/
?>
<!-- ######################## beginning of footer ################ -->
<!-- 				</td> 
			</tr> -->
			<tr>
				<td height="5" valign="bottom" class="footer" bgcolor="#CCCCCC">&nbsp;</td>
				
				<td height="5" valign="bottom" class="footer" bgcolor="#CCCCCC">
					&copy; 2002-2006 by Luc de Louw | 
					 <a href="http://www.web-cyradm.org"
					target="_new">http://www.web-cyradm.org</a> | <?php print _("translated by: ").$nls['translator']["$LANG"]; ?> | you are running web-cyradm Version <?php print $VERSION; ?>
				</td>
			</tr>
		</table>
	</body>
</html>
<!-- ######################## end of footer #################### -->
