ALTER TABLE `mail`.`domain` ADD `transport` VARCHAR(255) DEFAULT 'cyrus' NOT NULL
